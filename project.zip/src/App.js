import React, { useState, useRef } from 'react';

// Componente de encabezado
const LaborHeader = () => (
  <header className="bg-indigo-800 text-white py-6 shadow-lg">
    <div className="container mx-auto px-4 text-center">
      <h1 className="text-3xl font-bold">LaborCheck IBL18</h1>
      <p className="mt-2">Verificador de derechos laborales en Colombia</p>
    </div>
  </header>
);

// Componente del semáforo
const ResponsiveTrafficLight = ({ status }) => (
  <div className="flex flex-col items-center justify-center py-8">
    <div className="relative w-32 h-96 bg-gray-800 rounded-xl p-4 shadow-xl">
      <div className={`absolute top-4 left-1/2 transform -translate-x-1/2 w-20 h-20 rounded-full ${status === 'red' ? 'bg-red-600 shadow-lg shadow-red-600/50' : 'bg-red-900'} transition-all`}></div>
      <div className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full ${status === 'yellow' ? 'bg-yellow-500 shadow-lg shadow-yellow-500/50' : 'bg-yellow-900'} transition-all`}></div>
      <div className={`absolute bottom-4 left-1/2 transform -translate-x-1/2 w-20 h-20 rounded-full ${status === 'green' ? 'bg-green-600 shadow-lg shadow-green-600/50' : 'bg-green-900'} transition-all`}></div>
    </div>
    <div className="mt-8 text-center max-w-md mx-auto">
      {status === 'red' && (
        <div className="bg-red-100 border-l-4 border-red-600 text-red-800 p-4">
          <h3 className="font-bold">Alerta Roja</h3>
          <p>Tu trabajo NO cumple con los derechos básicos. Alto riesgo de no recibir salario completo o prestaciones.</p>
        </div>
      )}
      {status === 'yellow' && (
        <div className="bg-yellow-100 border-l-4 border-yellow-600 text-yellow-800 p-4">
          <h3 className="font-bold">Precaución Amarilla</h3>
          <p>Tu trabajo tiene irregularidades. Podrían faltar pagos de horas extras u otras deficiencias.</p>
        </div>
      )}
      {status === 'green' && (
        <div className="bg-green-100 border-l-4 border-green-600 text-green-800 p-4">
          <h3 className="font-bold">Todo en Verde</h3>
          <p>¡Felicidades! Tu empleo cumple con todos los derechos laborales colombianos.</p>
        </div>
      )}
    </div>
  </div>
);

// Componente de referencia legal estilizada
const StyledLegalReference = ({ law }) => (
  <span className="inline-block bg-indigo-100 text-indigo-800 text-xs font-semibold px-2.5 py-0.5 rounded-full mr-2 mb-1.5">
    {law}
  </span>
);

// Componente de tarjeta de pregunta mejorada
const EnhancedQuestionCard = ({ question, name, law, value, onChange, index, innerRef, highlight }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      ref={innerRef}
      className={`relative bg-white p-6 rounded-xl shadow-md mb-4 transition-all duration-300 border-l-4 ${
        value === 'yes' ? 'border-green-500' : 
        value === 'no' ? 'border-red-500' : 
        'border-gray-300'
      } ${
        isHovered ? 'transform hover:-translate-y-1 hover:shadow-lg' : ''
      } ${
        highlight && !value ? 'animate-pulse bg-yellow-50' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex flex-col sm:flex-row sm:items-start justify-between">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">{question}</h3>
          <StyledLegalReference law={law} />
        </div>
        <div className="flex space-x-4 mt-3 sm:mt-0">
          <label className="inline-flex items-center">
            <input
              type="radio"
              name={name}
              value="yes"
              checked={value === 'yes'}
              onChange={onChange}
              className="h-5 w-5 text-green-600 focus:ring-green-500 border-gray-300"
            />
            <span className="ml-3 text-gray-700 font-medium">Sí</span>
          </label>
          <label className="inline-flex items-center">
            <input
              type="radio"
              name={name}
              value="no"
              checked={value === 'no'}
              onChange={onChange}
              className="h-5 w-5 text-red-600 focus:ring-red-500 border-gray-300"
            />
            <span className="ml-3 text-gray-700 font-medium">No</span>
          </label>
        </div>
      </div>
    </div>
  );
};

// Componente de sección por categoría
const CategorySection = ({ title, description, questions, answers, handleChange, questionRefs, highlightMissing }) => (
  <div className="mb-10">
    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 mb-6 shadow-lg">
      <h3 className="text-2xl font-bold text-white">{title}</h3>
      <p className="text-indigo-100 mt-2">{description}</p>
    </div>
    
    <div className="space-y-4">
      {questions.map((q, index) => (
        <EnhancedQuestionCard
          key={index}
          question={`${index + 1}. ${q.question}`}
          name={q.name}
          law={q.law}
          value={answers[q.name]}
          onChange={handleChange}
          index={index}
          innerRef={questionRefs[q.name]}
          highlight={highlightMissing && !answers[q.name]}
        />
      ))}
    </div>
  </div>
);

// Componente del cuestionario completo
const CompleteQuestionnaire = ({ answers, handleChange, questionRefs, highlightMissing }) => {
  const categories = [
    {
      title: "Contratación",
      description: "Requisitos formales de la relación laboral",
      questions: [
        {
          question: "¿Tienes contrato de trabajo escrito y firmado?",
          name: "contract",
          law: "Art. 22 CST"
        },
        {
          question: "¿Recibes al menos el salario mínimo legal vigente?",
          name: "salary",
          law: "Art. 145 CST"
        }
      ]
    },
    {
      title: "Jornada Laboral",
      description: "Horarios y descansos establecidos por ley",
      questions: [
        {
          question: "¿Tu jornada laboral es de máximo 48 horas semanales?",
          name: "workingHours",
          law: "Art. 158-160 CST"
        },
        {
          question: "¿Te pagan correctamente las horas extras (25% diurno, 75% nocturno, 100% festivo)?",
          name: "overtime",
          law: "Art. 168 CST"
        },
        {
          question: "¿Tienes mínimo 1 día de descanso semanal remunerado?",
          name: "restDay",
          law: "Art. 177 CST"
        }
      ]
    },
    {
      title: "Prestaciones Sociales",
      description: "Beneficios económicos adicionales al salario",
      questions: [
        {
          question: "¿Recibes prestaciones sociales completas (cesantías, prima, vacaciones)?",
          name: "benefits",
          law: "Art. 249, 306, 186 CST"
        },
        {
          question: "¿Disfrutas de 15 días hábiles de vacaciones remuneradas por año?",
          name: "vacations",
          law: "Art. 186 CST"
        },
        {
          question: "¿Recibes prima de servicios (15 días en junio y 15 en diciembre)?",
          name: "bonus",
          law: "Art. 306 CST"
        },
        {
          question: "¿Te consignan las cesantías anualmente (1 mes por año trabajado)?",
          name: "severance",
          law: "Art. 249 CST"
        }
      ]
    },
    {
      title: "Protección Social",
      description: "Seguridad y garantías para el trabajador",
      questions: [
        {
          question: "¿Estás afiliado a salud, pensión y ARL?",
          name: "socialSecurity",
          law: "Ley 100/93"
        }
      ]
    },
    {
      title: "Terminación del Contrato",
      description: "Derechos al finalizar la relación laboral",
      questions: [
        {
          question: "¿Te pagarían liquidación completa si termina tu contrato?",
          name: "termination",
          law: "Art. 64-65 CST"
        },
        {
          question: "¿Te darían preaviso de 30 días antes de terminación unilateral?",
          name: "notice",
          law: "Art. 64 CST"
        }
      ]
    },
    {
      title: "Derechos Colectivos",
      description: "Libertades laborales fundamentales",
      questions: [
        {
          question: "¿Puedes asociarte libremente sin represalias?",
          name: "association",
          law: "Art. 39 Constitución"
        }
      ]
    }
  ];

  return (
    <div>
      {categories.map((category, index) => (
        <CategorySection
          key={index}
          title={category.title}
          description={category.description}
          questions={category.questions}
          answers={answers}
          handleChange={handleChange}
          questionRefs={questionRefs}
          highlightMissing={highlightMissing}
        />
      ))}
    </div>
  );
};

// Componente de informe de evaluación
const EvaluationReport = ({ answers }) => {
  const rights = [
    {
      question: "Contrato escrito firmado",
      key: "contract",
      law: "Artículo 22 CST",
      importance: "Alto"
    },
    {
      question: "Salario mínimo legal",
      key: "salary", 
      law: "Artículo 145 CST",
      importance: "Alto"
    },
    {
      question: "Jornada máxima 48h/semana",
      key: "workingHours",
      law: "Artículos 158-160 CST",
      importance: "Medio"
    },
    {
      question: "Pago de horas extras",
      key: "overtime",
      law: "Artículo 168 CST",
      importance: "Medio"
    },
    {
      question: "Descanso semanal remunerado",
      key: "restDay",
      law: "Artículo 177 CST",
      importance: "Medio"
    },
    {
      question: "Prestaciones sociales",
      key: "benefits",
      law: "Artículos 249, 306, 186 CST",
      importance: "Alto"
    },
    {
      question: "Vacaciones remuneradas",
      key: "vacations",
      law: "Artículo 186 CST",
      importance: "Medio"
    },
    {
      question: "Prima de servicios",
      key: "bonus",
      law: "Artículo 306 CST",
      importance: "Medio"
    },
    {
      question: "Consignación de cesantías",
      key: "severance",
      law: "Artículo 249 CST",
      importance: "Medio"
    },
    {
      question: "Seguridad social (salud, pensión, ARL)",
      key: "socialSecurity",
      law: "Ley 100 de 1993",
      importance: "Alto"
    },
    {
      question: "Liquidación completa al terminar",
      key: "termination",
      law: "Artículos 64-65 CST",
      importance: "Medio"
    },
    {
      question: "Preaviso de 30 días",
      key: "notice",
      law: "Artículo 64 CST",
      importance: "Medio"
    },
    {
      question: "Derecho a asociación sindical",
      key: "association",
      law: "Artículo 39 Constitución",
      importance: "Bajo"
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-md p-6 mt-8">
      <h3 className="text-2xl font-bold text-gray-800 mb-6">Informe de Cumplimiento</h3>
      <div className="space-y-4">
        {rights.map((right, index) => (
          <div key={index} className="border-b border-gray-200 pb-4">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium text-gray-800">{right.question}</h4>
                <p className="text-sm text-gray-600">{right.law}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                answers[right.key] === 'yes' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {answers[right.key] === 'yes' ? 'Cumple' : 'No cumple'}
              </span>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              Importancia: <span className="font-medium">{right.importance}</span>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

// Componente de alerta de validación
const ValidationAlert = ({ missingQuestions, onClose, onNavigate }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
    <div className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full">
      <h3 className="text-xl font-bold text-red-600 mb-4">¡Faltan respuestas!</h3>
      <p className="text-gray-700 mb-4">
        Por favor responde las siguientes preguntas para poder evaluar tu situación laboral:
      </p>
      <ul className="list-disc pl-5 mb-6 space-y-1">
        {missingQuestions.map((q, index) => (
          <li key={index} className="text-gray-800">
            {q}
          </li>
        ))}
      </ul>
      <div className="flex justify-end space-x-3">
        <button
          onClick={onClose}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
        >
          Cerrar
        </button>
        <button
          onClick={onNavigate}
          className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
        >
          Ir a la primera pregunta
        </button>
      </div>
    </div>
  </div>
);

// Componente de lista de derechos laborales
const LaborRightsList = () => {
  const rights = [
    {
      title: "Contrato de Trabajo",
      description: "Debe ser escrito, con condiciones claras y firmado por ambas partes.",
      law: "Artículo 22 CST"
    },
    {
      title: "Salario Mínimo Legal",
      description: "No puede ser inferior al salario mínimo mensual vigente ($1.160.000 en 2023).",
      law: "Artículo 145 CST"
    },
    {
      title: "Jornada Laboral",
      description: "Máximo 48 horas semanales (8 horas diarias). Diurno: 6am-9pm, Nocturno: 9pm-6am.",
      law: "Artículos 158-160 CST"
    },
    {
      title: "Horas Extras",
      description: "Diurnas: recargo 25%, Nocturnas: recargo 75%, Festivos: recargo 100%.",
      law: "Artículo 168 CST"
    },
    {
      title: "Prestaciones Sociales",
      description: "Cesantías (1 mes/año), Prima de servicios (15 días semestre), Vacaciones (15 días/año).",
      law: "Artículos 249, 306, 186 CST"
    },
    {
      title: "Seguridad Social",
      description: "Afiliación obligatoria a salud, pensión y riesgos laborales (ARL).",
      law: "Ley 100 de 1993"
    },
    {
      title: "Liquidación",
      description: "Pago completo al terminar contrato, incluyendo prestaciones y preaviso.",
      law: "Artículos 64-65 CST"
    },
    {
      title: "Derecho a Asociación",
      description: "Libertad para sindicalizarse sin represalias.",
      law: "Artículo 39 Constitución"
    }
  ];

  return (
    <div className="bg-indigo-50 rounded-2xl p-6 shadow-inner my-8">
      <h3 className="text-2xl font-bold text-indigo-900 mb-6 text-center">Derechos Laborales en Colombia</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rights.map((right, index) => (
          <div 
            key={index}
            className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border-l-4 border-indigo-500"
          >
            <h4 className="text-lg font-semibold text-indigo-800 mb-2">{right.title}</h4>
            <p className="text-gray-700 mb-3">{right.description}</p>
            <span className="text-sm text-indigo-600 font-medium">{right.law}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// Componente principal App
const App = () => {
  const [status, setStatus] = useState(null);
  const [showReport, setShowReport] = useState(false);
  const [showValidationAlert, setShowValidationAlert] = useState(false);
  const [missingQuestions, setMissingQuestions] = useState([]);
  const [highlightMissing, setHighlightMissing] = useState(false);
  
  const questionRefs = {
    contract: useRef(null),
    salary: useRef(null),
    workingHours: useRef(null),
    overtime: useRef(null),
    restDay: useRef(null),
    benefits: useRef(null),
    socialSecurity: useRef(null),
    vacations: useRef(null),
    bonus: useRef(null),
    severance: useRef(null),
    termination: useRef(null),
    notice: useRef(null),
    association: useRef(null)
  };

  const questionsMap = {
    contract: "1. Contrato de trabajo escrito y firmado",
    salary: "2. Salario mínimo legal vigente",
    workingHours: "3. Jornada máxima 48 horas semanales",
    overtime: "4. Pago de horas extras",
    restDay: "5. Descanso semanal remunerado",
    benefits: "6. Prestaciones sociales completas",
    socialSecurity: "7. Afiliación a salud, pensión y ARL",
    vacations: "8. Vacaciones remuneradas",
    bonus: "9. Prima de servicios",
    severance: "10. Consignación de cesantías",
    termination: "11. Liquidación completa",
    notice: "12. Preaviso de 30 días",
    association: "13. Derecho a asociación sindical"
  };

  const [answers, setAnswers] = useState({
    contract: '',
    salary: '',
    workingHours: '',
    overtime: '',
    restDay: '',
    benefits: '',
    socialSecurity: '',
    vacations: '',
    bonus: '',
    severance: '',
    termination: '',
    notice: '',
    association: ''
  });

  const validateForm = () => {
    const missing = [];
    Object.keys(answers).forEach(key => {
      if (!answers[key]) {
        missing.push(questionsMap[key]);
      }
    });
    setMissingQuestions(missing);
    return missing.length === 0;
  };

  const scrollToFirstMissing = () => {
    if (missingQuestions.length > 0) {
      const firstMissingKey = Object.keys(questionsMap).find(key => 
        questionsMap[key] === missingQuestions[0]
      );
      if (firstMissingKey && questionRefs[firstMissingKey].current) {
        questionRefs[firstMissingKey].current.scrollIntoView({
          behavior: 'smooth',
          block: 'center'
        });
      }
    }
    setHighlightMissing(true);
    setTimeout(() => setHighlightMissing(false), 3000);
  };

  const evaluateStatus = () => {
    const {
      contract, salary, workingHours, overtime, restDay,
      benefits, socialSecurity, vacations, bonus, severance,
      termination, notice, association
    } = answers;
    
    const basicRights = [contract, salary, socialSecurity, benefits];
    if (basicRights.some(answer => !answer || answer === 'no')) {
      return 'red';
    }
    
    const intermediateRights = [workingHours, overtime, restDay, vacations, bonus, severance];
    if (intermediateRights.some(answer => !answer || answer === 'no')) {
      return 'yellow';
    }
    
    const fullRights = [termination, notice, association];
    if (fullRights.every(answer => answer === 'yes')) {
      return 'green';
    }
    
    return 'yellow';
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAnswers(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      const result = evaluateStatus();
      setStatus(result);
      setShowReport(true);
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    } else {
      setShowValidationAlert(true);
      scrollToFirstMissing();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <LaborHeader />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {showReport ? (
            <>
              <div className="mb-12">
                <ResponsiveTrafficLight status={status} />
                <EvaluationReport answers={answers} />
              </div>
              
              <div className="mt-12">
                <h2 className="text-2xl font-bold text-center mb-8">Conoce más sobre tus derechos laborales</h2>
                <LaborRightsList />
              </div>
              
              <div className="mt-8 text-center">
                <button
                  onClick={() => {
                    setShowReport(false);
                    setStatus(null);
                    setAnswers({
                      contract: '',
                      salary: '',
                      workingHours: '',
                      overtime: '',
                      restDay: '',
                      benefits: '',
                      socialSecurity: '',
                      vacations: '',
                      bonus: '',
                      severance: '',
                      termination: '',
                      notice: '',
                      association: ''
                    });
                  }}
                  className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Realizar nueva evaluación
                </button>
              </div>
            </>
          ) : (
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl shadow-xl overflow-hidden">
              <div className="p-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
                  Evaluación Completa de Derechos Laborales
                </h2>
                
                <form onSubmit={handleSubmit}>
                  <CompleteQuestionnaire 
                    answers={answers}
                    handleChange={handleChange}
                    questionRefs={questionRefs}
                    highlightMissing={highlightMissing}
                  />
                  
                  <div className="px-4 py-6 text-center">
                    <button
                      type="submit"
                      className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all transform hover:scale-105"
                    >
                      Evaluar mi situación laboral
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="mb-2">© 2025 Creado por IBL18 - Basado en el Código Sustantivo del Trabajo</p>
          <p className="text-sm text-gray-400">Herramienta informativa - Consulta un abogado laboral para asesoría específica.</p>
        </div>
      </footer>

      {showValidationAlert && (
        <ValidationAlert
          missingQuestions={missingQuestions}
          onClose={() => setShowValidationAlert(false)}
          onNavigate={() => {
            setShowValidationAlert(false);
            scrollToFirstMissing();
          }}
        />
      )}
    </div>
  );
};

export default App;
// DONE