import React from 'react';

const QuestionCard = ({ question, name, onChange, value }) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md mb-4">
      <h3 className="text-lg font-medium text-gray-900 mb-4">{question}</h3>
      <div className="flex flex-col space-y-3 sm:space-y-0 sm:flex-row sm:space-x-6">
        <label className="inline-flex items-center">
          <input
            type="radio"
            name={name}
            value="yes"
            checked={value === 'yes'}
            onChange={onChange}
            className="h-4 w-4 text-green-600 focus:ring-green-500"
          />
          <span className="ml-2 text-gray-700">Sí</span>
        </label>
        <label className="inline-flex items-center">
          <input
            type="radio"
            name={name}
            value="no"
            checked={value === 'no'}
            onChange={onChange}
            className="h-4 w-4 text-red-600 focus:ring-red-500"
          />
          <span className="ml-2 text-gray-700">No</span>
        </label>
      </div>
    </div>
  );
};

export default QuestionCard;