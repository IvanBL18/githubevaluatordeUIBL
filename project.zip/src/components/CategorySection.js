import React from 'react';
import EnhancedQuestionCard from './EnhancedQuestionCard';

const CategorySection = ({ title, description, questions, answers, handleChange }) => {
  return (
    <div className="mb-10">
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 mb-6 shadow-lg">
        <h3 className="text-2xl font-bold text-white">{title}</h3>
        <p className="text-indigo-100 mt-2">{description}</p>
      </div>
      
      <div className="space-y-4">
        {questions.map((q, index) => (
          <EnhancedQuestionCard
            key={index}
            question={`${index + 1}. ${q.question}`}
            name={q.name}
            law={q.law}
            value={answers[q.name]}
            onChange={handleChange}
            index={index}
          />
        ))}
      </div>
    </div>
  );
};

export default CategorySection;