import React from 'react';

const EvaluationReport = ({ answers }) => {
  const rights = [
    {
      question: "Contrato escrito firmado",
      key: "contract",
      law: "Artículo 22 CST",
      importance: "Alto"
    },
    {
      question: "Salario mínimo legal",
      key: "salary", 
      law: "Artículo 145 CST",
      importance: "Alto"
    },
    {
      question: "Jornada máxima 48h/semana",
      key: "workingHours",
      law: "Artículos 158-160 CST",
      importance: "Medio"
    },
    {
      question: "Pago de horas extras",
      key: "overtime",
      law: "Artículo 168 CST",
      importance: "Medio"
    },
    {
      question: "Prestaciones sociales",
      key: "benefits",
      law: "Artículos 249, 306, 186 CST",
      importance: "Alto"
    },
    {
      question: "Seguridad social (salud, pensión, ARL)",
      key: "socialSecurity",
      law: "Ley 100 de 1993",
      importance: "Alto"
    },
    {
      question: "Liquidación completa al terminar",
      key: "termination",
      law: "Artículos 64-65 CST",
      importance: "Medio"
    },
    {
      question: "Derecho a asociación sindical",
      key: "association",
      law: "Artículo 39 Constitución",
      importance: "Bajo"
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-md p-6 mt-8">
      <h3 className="text-2xl font-bold text-gray-800 mb-6">Informe de Cumplimiento</h3>
      <div className="space-y-4">
        {rights.map((right, index) => (
          <div key={index} className="border-b border-gray-200 pb-4">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium text-gray-800">{right.question}</h4>
                <p className="text-sm text-gray-600">{right.law}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                answers[right.key] === 'yes' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {answers[right.key] === 'yes' ? 'Cumple' : 'No cumple'}
              </span>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              Importancia: <span className="font-medium">{right.importance}</span>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EvaluationReport;