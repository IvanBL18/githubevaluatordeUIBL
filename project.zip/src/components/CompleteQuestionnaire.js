import React from 'react';
import CategorySection from './CategorySection';

const CompleteQuestionnaire = ({ answers, handleChange }) => {
  const categories = [
    {
      title: "Contratación",
      description: "Requisitos formales de la relación laboral",
      questions: [
        {
          question: "¿Tienes contrato de trabajo escrito y firmado?",
          name: "contract",
          law: "Art. 22 CST"
        },
        {
          question: "¿Recibes al menos el salario mínimo legal vigente?",
          name: "salary",
          law: "Art. 145 CST"
        }
      ]
    },
    {
      title: "Jornada Laboral",
      description: "Horarios y descansos establecidos por ley",
      questions: [
        {
          question: "¿Tu jornada laboral es de máximo 48 horas semanales?",
          name: "workingHours",
          law: "Art. 158-160 CST"
        },
        {
          question: "¿Te pagan correctamente las horas extras (25% diurno, 75% nocturno, 100% festivo)?",
          name: "overtime",
          law: "Art. 168 CST"
        },
        {
          question: "¿Tienes mínimo 1 día de descanso semanal remunerado?",
          name: "restDay",
          law: "Art. 177 CST"
        }
      ]
    },
    {
      title: "Prestaciones Sociales",
      description: "Beneficios económicos adicionales al salario",
      questions: [
        {
          question: "¿Recibes prestaciones sociales completas (cesantías, prima, vacaciones)?",
          name: "benefits",
          law: "Art. 249, 306, 186 CST"
        },
        {
          question: "¿Disfrutas de 15 días hábiles de vacaciones remuneradas por año?",
          name: "vacations",
          law: "Art. 186 CST"
        },
        {
          question: "¿Recibes prima de servicios (15 días en junio y 15 en diciembre)?",
          name: "bonus",
          law: "Art. 306 CST"
        },
        {
          question: "¿Te consignan las cesantías anualmente (1 mes por año trabajado)?",
          name: "severance",
          law: "Art. 249 CST"
        }
      ]
    },
    {
      title: "Protección Social",
      description: "Seguridad y garantías para el trabajador",
      questions: [
        {
          question: "¿Estás afiliado a salud, pensión y ARL?",
          name: "socialSecurity",
          law: "Ley 100/93"
        }
      ]
    },
    {
      title: "Terminación del Contrato",
      description: "Derechos al finalizar la relación laboral",
      questions: [
        {
          question: "¿Te pagarían liquidación completa si termina tu contrato?",
          name: "termination",
          law: "Art. 64-65 CST"
        },
        {
          question: "¿Te darían preaviso de 30 días antes de terminación unilateral?",
          name: "notice",
          law: "Art. 64 CST"
        }
      ]
    },
    {
      title: "Derechos Colectivos",
      description: "Libertades laborales fundamentales",
      questions: [
        {
          question: "¿Puedes asociarte libremente sin represalias?",
          name: "association",
          law: "Art. 39 Constitución"
        }
      ]
    }
  ];

  return (
    <div>
      {categories.map((category, index) => (
        <CategorySection
          key={index}
          title={category.title}
          description={category.description}
          questions={category.questions}
          answers={answers}
          handleChange={handleChange}
        />
      ))}
    </div>
  );
};

export default CompleteQuestionnaire;

// DONE