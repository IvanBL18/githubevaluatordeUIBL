import React from 'react';

const LaborRightsList = () => {
  const rights = [
    {
      title: "Contrato de Trabajo",
      description: "Debe ser escrito, con condiciones claras y firmado por ambas partes.",
      law: "Artículo 22 CST"
    },
    {
      title: "Salario Mínimo Legal",
      description: "No puede ser inferior al salario mínimo mensual vigente ($1.160.000 en 2023).",
      law: "Artículo 145 CST"
    },
    {
      title: "Jornada Laboral",
      description: "Máximo 48 horas semanales (8 horas diarias). Diurno: 6am-9pm, Nocturno: 9pm-6am.",
      law: "Artículos 158-160 CST"
    },
    {
      title: "Horas Extras",
      description: "Diurnas: recargo 25%, Nocturnas: recargo 75%, Festivos: recargo 100%.",
      law: "Artículo 168 CST"
    },
    {
      title: "Prestaciones Sociales",
      description: "Cesantías (1 mes/año), Prima de servicios (15 días semestre), Vacaciones (15 días/año).",
      law: "Artículos 249, 306, 186 CST"
    },
    {
      title: "Seguridad Social",
      description: "Afiliación obligatoria a salud, pensión y riesgos laborales (ARL).",
      law: "Ley 100 de 1993"
    },
    {
      title: "Liquidación",
      description: "Pago completo al terminar contrato, incluyendo prestaciones y preaviso.",
      law: "Artículos 64-65 CST"
    },
    {
      title: "Derecho a Asociación",
      description: "Libertad para sindicalizarse sin represalias.",
      law: "Artículo 39 Constitución"
    }
  ];

  return (
    <div className="bg-indigo-50 rounded-2xl p-6 shadow-inner my-8">
      <h3 className="text-2xl font-bold text-indigo-900 mb-6 text-center">Derechos Laborales en Colombia</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {rights.map((right, index) => (
          <div 
            key={index}
            className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300 border-l-4 border-indigo-500"
          >
            <h4 className="text-lg font-semibold text-indigo-800 mb-2">{right.title}</h4>
            <p className="text-gray-700 mb-3">{right.description}</p>
            <span className="text-sm text-indigo-600 font-medium">{right.law}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LaborRightsList;