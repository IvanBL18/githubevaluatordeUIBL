import React, { useState, useEffect } from 'react';

const AnimatedQuestionCard = ({ question, name, onChange, value, index }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100 * index);
    return () => clearTimeout(timer);
  }, [index]);

  return (
    <div 
      className={`bg-white p-6 rounded-xl shadow-lg mb-6 transform transition-all duration-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}
      style={{
        background: 'linear-gradient(145deg, #ffffff, #f8f9fa)',
        borderLeft: '4px solid',
        borderLeftColor: value === 'yes' ? '#10b981' : value === 'no' ? '#ef4444' : '#6b7280'
      }}
    >
      <h3 className="text-xl font-semibold text-gray-800 mb-4">{question}</h3>
      <div className="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:space-x-6">
        <label className="inline-flex items-center">
          <input
            type="radio"
            name={name}
            value="yes"
            checked={value === 'yes'}
            onChange={onChange}
            className="h-5 w-5 text-green-600 focus:ring-green-500 border-gray-300"
          />
          <span className="ml-3 text-gray-700 font-medium">Sí</span>
        </label>
        <label className="inline-flex items-center">
          <input
            type="radio"
            name={name}
            value="no"
            checked={value === 'no'}
            onChange={onChange}
            className="h-5 w-5 text-red-600 focus:ring-red-500 border-gray-300"
          />
          <span className="ml-3 text-gray-700 font-medium">No</span>
        </label>
      </div>
    </div>
  );
};

export default AnimatedQuestionCard;