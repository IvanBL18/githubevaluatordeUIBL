import React, { useState } from 'react';
import StyledLegalReference from './StyledLegalReference';

const EnhancedQuestionCard = ({ question, name, law, value, onChange, index }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className={`relative bg-white p-6 rounded-xl shadow-md mb-4 transition-all duration-300 border-l-4 ${
        value === 'yes' ? 'border-green-500' : 
        value === 'no' ? 'border-red-500' : 
        'border-gray-300'
      } ${
        isHovered ? 'transform hover:-translate-y-1 hover:shadow-lg' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex flex-col sm:flex-row sm:items-start justify-between">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">{question}</h3>
          <StyledLegalReference law={law} />
        </div>
        <div className="flex space-x-4 mt-3 sm:mt-0">
          <label className="inline-flex items-center">
            <input
              type="radio"
              name={name}
              value="yes"
              checked={value === 'yes'}
              onChange={onChange}
              className="h-5 w-5 text-green-600 focus:ring-green-500 border-gray-300"
            />
            <span className="ml-3 text-gray-700 font-medium">Sí</span>
          </label>
          <label className="inline-flex items-center">
            <input
              type="radio"
              name={name}
              value="no"
              checked={value === 'no'}
              onChange={onChange}
              className="h-5 w-5 text-red-600 focus:ring-red-500 border-gray-300"
            />
            <span className="ml-3 text-gray-700 font-medium">No</span>
          </label>
        </div>
      </div>
    </div>
  );
};

export default EnhancedQuestionCard;