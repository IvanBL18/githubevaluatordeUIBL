import React from 'react';

const StyledLegalReference = ({ law }) => {
  return (
    <span className="inline-block bg-indigo-100 text-indigo-800 text-xs font-semibold px-2.5 py-0.5 rounded-full mr-2 mb-1.5">
      {law}
    </span>
  );
};

export default StyledLegalReference;