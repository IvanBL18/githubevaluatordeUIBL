import React from 'react';

const ResponsiveTrafficLight = ({ status }) => {
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="relative w-32 h-96 bg-gray-800 rounded-xl p-4 shadow-xl">
        {/* Red Light */}
        <div className={`absolute top-4 left-1/2 transform -translate-x-1/2 w-20 h-20 rounded-full ${status === 'red' ? 'bg-red-600 shadow-lg shadow-red-600/50' : 'bg-red-900'} transition-all`}></div>
        
        {/* Yellow Light */}
        <div className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-20 h-20 rounded-full ${status === 'yellow' ? 'bg-yellow-500 shadow-lg shadow-yellow-500/50' : 'bg-yellow-900'} transition-all`}></div>
        
        {/* Green Light */}
        <div className={`absolute bottom-4 left-1/2 transform -translate-x-1/2 w-20 h-20 rounded-full ${status === 'green' ? 'bg-green-600 shadow-lg shadow-green-600/50' : 'bg-green-900'} transition-all`}></div>
      </div>
      <div className="mt-8 text-center max-w-md mx-auto">
        {status === 'red' && (
          <div className="bg-red-100 border-l-4 border-red-600 text-red-800 p-4">
            <h3 className="font-bold">Alerta Roja</h3>
            <p>Tu trabajo NO cumple con los derechos básicos. Tienes alto riesgo de no recibir salario completo o prestaciones. Revisa tu contrato y consulta un abogado laboral.</p>
          </div>
        )}
        {status === 'yellow' && (
          <div className="bg-yellow-100 border-l-4 border-yellow-600 text-yellow-800 p-4">
            <h3 className="font-bold">Precaución Amarilla</h3>
            <p>Tu trabajo tiene algunas irregularidades. Podrían faltar pagos de horas extras o tener otras deficiencias. Verifica cada punto con tu empleador.</p>
          </div>
        )}
        {status === 'green' && (
          <div className="bg-green-100 border-l-4 border-green-600 text-green-800 p-4">
            <h3 className="font-bold">Todo en Verde</h3>
            <p>¡Felicidades! Tu empleo cumple con los derechos laborales colombianos. Tienes contrato, prestaciones y protección legal completa.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResponsiveTrafficLight;